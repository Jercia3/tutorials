import "./App.css";
import { useState, useEffect } from "react";
import { render } from "react-dom";


const tahoe_peaks = [
  {name: "freel", elevation: 109},
  {name: "Monumnet", elevation: 100}
]

function List({data, renderItem, renderEmpty}) {
  return !data.length ? (
    renderEmpty
  ) : (
    <ul>
      {data.map((item) => (
        <li key = {item.name}>
          {renderItem(item)}
        </li>
      ))}
    </ul>
  )
}

function App() {
  return (
    <List data = {tahoe_peaks} renderEmpty = {<p> this list is empty</p>}
    renderItem = {(item) => (
      <>
        {item.name} - {item.elevation} ft.
      </>
    )}

  );


}
  
export default App;
