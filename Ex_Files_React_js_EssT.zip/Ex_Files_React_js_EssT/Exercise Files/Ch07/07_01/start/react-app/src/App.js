import "./App.css";



function Home() {
  return (
    <div>
      <h1>My website</h1>
    </div>
  );
}

function About() {
  return (
    <div>
      <h1>About Us</h1>
    </div>
  );
}

function Contact() {
  return (
    <div>
      <h1>Conatct</h1>
    </div>
  );
}

function App() {
  return (
    <Home/>
  );
}
export default App;
