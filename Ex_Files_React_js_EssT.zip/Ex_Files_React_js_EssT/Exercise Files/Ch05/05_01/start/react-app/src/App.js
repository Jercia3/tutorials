import "./App.css";
import { useReducer } from "react";

function App() {
  const txtTitle = useRef();
  const hexColor = useRef();

  const submit = (e) => {
    e.preventDefault();
    const title =txtTitle.current.value;
    const color = hexColor.current.value;
    alert('${title}, ${color}');
    txtTitle.current.value = "";
    txtTitle.current.value="";
  };
  
  return (
    <form>
      <input
      ref={txtTitle}
        type="text"
        placeholder="color title..."
      />
      <input ref={hexColor} type="color" />
      <button>ADD</button>

    </form>
  );
}

export default App;
