import timesTwo from "./functions";



test("Multiplies by 2", () => {
    expect(timesTwo(4)).toBe(8);
});