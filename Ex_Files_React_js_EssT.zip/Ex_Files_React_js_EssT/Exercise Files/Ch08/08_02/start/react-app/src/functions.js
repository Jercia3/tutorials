export default function timesTwo() {
    return a * 2;
}